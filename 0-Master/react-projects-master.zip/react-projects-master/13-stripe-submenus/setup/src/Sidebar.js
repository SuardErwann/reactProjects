import React from 'react'
import { FaTimes } from 'react-icons/fa'
import sublinks from './data'

const Sidebar = () => {
  return <h2>sidebar component</h2>
}

export default Sidebar
