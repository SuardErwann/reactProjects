import React from 'react'
import { useGlobalContext } from './context'

const SetupForm = () => {
  return <h2>setup form</h2>
}

export default SetupForm
