import React from 'react'
import { FaEdit, FaTrash } from 'react-icons/fa'
const List = () => {
  return <h2>list component</h2>
}

export default List
